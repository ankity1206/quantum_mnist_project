# Quantum MNIST — finalization bundle

This bundle contains the final report and consolidated results table based on the project results summarized during the conversation.

## Files
- `quantum_mnist_final_report.docx` — methods, results, discussion, limitations, configuration, and preservation checklist.
- `final_results_table.csv` — consolidated table of experiments, headline metrics, and relative output paths.

## Important interpretation
The cosine-feature control computes `cos(x + phase)` classically and reproduces the useful behavior of the non-entangled circuit. These experiments do **not** establish quantum computational advantage.

The full official MNIST test set was used after a 1,000-image subset of it had already been used in earlier experiments. It is not an untouched final holdout.

## Local archive commands
Run these commands on the machine containing `~/Desktop/qskit/quantum_mnist`. They preserve existing experiment folders by copying the project to a timestamped archive; they do not delete or overwrite the source project.

```bash
cd ~/Desktop/qskit
tar --exclude='quantum_mnist/.git' --exclude='quantum_mnist/q-env' \
    -czf "quantum_mnist_archive_$(date +%Y%m%d_%H%M%S).tar.gz" quantum_mnist
sha256sum quantum_mnist_archive_*.tar.gz
```

If you need a fully self-contained archive that includes the virtual environment, omit the `--exclude='quantum_mnist/q-env'` option (the archive will be much larger and virtual environments are often not portable).

## Recommended final checks on the project machine
```bash
cd ~/Desktop/qskit/quantum_mnist
find . -maxdepth 2 -type f | sort > project_file_inventory.txt
python -m pip freeze > requirements-lock.txt
find outputs -type f \( -name '*.csv' -o -name '*.npz' -o -name '*.pt' -o -name '*.pth' \) | sort
```
