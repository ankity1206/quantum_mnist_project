#!/usr/bin/env bash
set -euo pipefail

PROJECT="${HOME}/Desktop/qskit/quantum_mnist"
PARENT="${HOME}/Desktop/qskit"
STAMP="$(date +%Y%m%d_%H%M%S)"
ARCHIVE="${PARENT}/quantum_mnist_final_archive_${STAMP}.tar.gz"

if [[ ! -d "$PROJECT" ]]; then
  echo "Project directory not found: $PROJECT" >&2
  exit 1
fi

cd "$PROJECT"
find . -path './q-env' -prune -o -path './.git' -prune -o -type f -print | sort > "project_file_inventory_${STAMP}.txt"
python -m pip freeze > "requirements-lock_${STAMP}.txt"

cd "$PARENT"
tar --exclude='quantum_mnist/.git' --exclude='quantum_mnist/q-env' \
    -czf "$ARCHIVE" quantum_mnist

sha256sum "$ARCHIVE" > "${ARCHIVE}.sha256"
echo "Archive created: $ARCHIVE"
echo "Checksum file: ${ARCHIVE}.sha256"
echo "Inventory and package lock saved inside the project directory."
echo "The original project was not deleted or modified beyond adding inventory/lock files."
